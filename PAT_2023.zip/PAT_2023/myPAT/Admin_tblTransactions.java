package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JScrollPane;

public class Admin_tblTransactions extends JFrame {

	private JPanel contentPane;
	private DatabaseConnect db = new DatabaseConnect();

	/**
	 * Create the frame.
	 */
	public Admin_tblTransactions(int num) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1039, 449);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 44, 715, 364);
		contentPane.add(scrollPane);
		
		JTextArea txaDisplay = new JTextArea(db.displayMeta("SELECT TransactionID, AccountID, CONCAT('R', CAST(Price AS DECIMAL(10, 2))) AS Cost, AmountToBuy, ProductName FROM tblTransactions"));
		scrollPane.setViewportView(txaDisplay);
		
		JLabel lblTitle = new JLabel("The history of the company's transactions with customers, data not editable for administrative reasons.");
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTitle.setBounds(10, 0, 701, 34);
		contentPane.add(lblTitle);
		
		JLabel lblReturn = new JLabel("Return to last window\r\n");
		lblReturn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblReturn.setBounds(735, 108, 280, 34);
		contentPane.add(lblReturn);
		
		JButton btnReturn = new JButton("Return\r\n");
		btnReturn.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnReturn.setBounds(735, 164, 280, 83);
		btnReturn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {// used to return to the last screen and return to program
				Adminlogin frame = new Adminlogin(num);
				
				frame.setVisible(true);
				
				dispose();
			}
			});
		contentPane.add(btnReturn);
	}
}
