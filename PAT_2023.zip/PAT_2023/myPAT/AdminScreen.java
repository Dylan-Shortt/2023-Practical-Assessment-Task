package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Action;

public class AdminScreen extends JFrame {

	private JPanel contentPane;
	private DatabaseConnect db = new DatabaseConnect();
	

	/**
	 * Create the frame.
	 */
	public AdminScreen(int num) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 959, 421);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("AdminScreen, used for checking, updating and managing data");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(10, 0, 925, 37);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 47, 519, 327);
		contentPane.add(scrollPane);
		
		JTextArea textArea = new JTextArea(db.displayMeta("Select * from RegisterTable"));
		textArea.setTabSize(15);
		scrollPane.setViewportView(textArea);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnUpdate.addActionListener(new ActionListener(){// opens the screen to update the table
			public void actionPerformed(ActionEvent e) {
				UpdateAdminWindow frame = new UpdateAdminWindow(num);
				frame.setVisible(true);
				dispose();
			}
			});
		btnUpdate.setBounds(539, 47, 406, 59);
		contentPane.add(btnUpdate);
		
		JButton btnInsert = new JButton("Insert");
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.addActionListener(new ActionListener(){// opens the screen to insert a record into accounts
			public void actionPerformed(ActionEvent e) {
				InsertAdminWindow frame = new InsertAdminWindow(num);
				frame.setVisible(true);
				dispose();
			}
			});
		btnInsert.setBounds(539, 135, 406, 59);
		contentPane.add(btnInsert);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnDelete.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {// opens the screen to delete from accounts
				DeleteAdminWindow frame = new DeleteAdminWindow(num);
				frame.setVisible(true);
				dispose();
			}
			});
		btnDelete.setBounds(539, 236, 406, 59);
		contentPane.add(btnDelete);
		
		JButton btnBack = new JButton("Back to Admin Window");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnBack.setBounds(539, 305, 396, 69);
		btnBack.addActionListener(new ActionListener(){// opens the screen to go back to admin
			public void actionPerformed(ActionEvent e) {
				Adminlogin frame = new Adminlogin(num);
				frame.setVisible(true);
				dispose();
			}
			});
		contentPane.add(btnBack);
	}
	
}
