package myPAT;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class DeleteAdminWindow extends JFrame {
	private DatabaseConnect db = new DatabaseConnect();
	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public DeleteAdminWindow(int num) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1254, 595);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 28, 768, 455);
		contentPane.add(scrollPane);
		
		JTextArea txaWindow = new JTextArea(db.displayMeta("Select * from RegisterTable"));
		txaWindow.setTabSize(15);
		scrollPane.setViewportView(txaWindow);
		
		JLabel lblNewLabel = new JLabel("The field to delete from :\r\n");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(788, 96, 315, 68);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Enter the values to be Deleted : \r\n");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(788, 40, 413, 29);
		contentPane.add(lblNewLabel_1);
		
		JTextField txtWhere = new JTextField();
		txtWhere.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtWhere.setColumns(10);
		txtWhere.setBounds(1097, 217, 133, 38);
		contentPane.add(txtWhere);
		
		JComboBox cmbCondition = new JComboBox();// creates the combo box with the field names entered
		cmbCondition.setFont(new Font("Tahoma", Font.PLAIN, 20));
		cmbCondition.setModel(new DefaultComboBoxModel(new String[] {"AccountID", "FirstName", "Surname", "Username", "Email", "Password", "PhoneNumber"}));
		cmbCondition.setBounds(1113, 107, 127, 55);
		contentPane.add(cmbCondition);
		
		JButton btnUpdate = new JButton("Delete");
		btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 40));
		btnUpdate.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {// button to run the delete names
				
				if(!txtWhere.getText().isBlank() || !txtWhere.getText().isEmpty())
				{
				String stmt = "";
				
				//DELETE FROM table_name
				stmt = "DELETE FROM RegisterTable";
				
				//WHERE condition;
				stmt += " WHERE ";
				
				//Condition
				stmt += cmbCondition.getSelectedItem().toString();
				
				//With match
				
				stmt += " = \"" + txtWhere.getText() + "\"";
				
				//System.out.println(stmt);
				String message = db.update(stmt);
				System.out.println(message);
				JOptionPane.showMessageDialog(null, message);
				
				//return to admin window
				AdminScreen frame = new AdminScreen(num);
				frame.setVisible(true);
				dispose();
				}
				else
				{
					JOptionPane.showMessageDialog(null, txtWhere.getText() + " Where must contail a value");
				}
			}
		});
		btnUpdate.setBounds(784, 368, 446, 180);
		contentPane.add(btnUpdate);
		
		JButton btnBack = new JButton("Back to admin"); /// return to the last opened screen
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnBack.setBounds(10, 493, 133, 55);
		btnBack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				Adminlogin frame = new Adminlogin(num);
				frame.setVisible(true);
				dispose();
			}
			});
		contentPane.add(btnBack);
		
		JLabel lblNewLabel_2 = new JLabel("The value to be deleted from that field :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(788, 217, 287, 38);
		contentPane.add(lblNewLabel_2);
	}
}
