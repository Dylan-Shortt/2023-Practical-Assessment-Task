package myPAT;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class InsertAdminWindow extends JFrame {
	private DatabaseConnect db = new DatabaseConnect();
	private JPanel contentPane;
	private InsertAdminWindowCheck IAWC = new InsertAdminWindowCheck();

	/**
	 * Create the frame.
	 */
	public InsertAdminWindow(int num) {// creates the insert frame
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1254, 595);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 28, 768, 455);
		contentPane.add(scrollPane);
		
		JTextArea txaWindow = new JTextArea(db.displayMeta("Select * from RegisterTable"));
		txaWindow.setTabSize(15);
		scrollPane.setViewportView(txaWindow);
		
		JLabel lblFirstName = new JLabel("Name:");
		lblFirstName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblFirstName.setBounds(788, 82, 101, 42);
		contentPane.add(lblFirstName);
		
		JLabel lblSurname = new JLabel("Surname:");
		lblSurname.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSurname.setBounds(788, 134, 101, 42);
		contentPane.add(lblSurname);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblUsername.setBounds(788, 203, 101, 42);
		contentPane.add(lblUsername);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEmail.setBounds(788, 266, 101, 42);
		contentPane.add(lblEmail);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPassword.setBounds(788, 334, 101, 42);
		contentPane.add(lblPassword);
		
		JLabel lblPhoneNumber = new JLabel("PhoneNumber:");
		lblPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPhoneNumber.setBounds(788, 386, 139, 42);
		contentPane.add(lblPhoneNumber);
		
		JLabel lblNewLabel_1 = new JLabel("Enter the values to be inserted into the table next to the names provided : \r\n");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(781, 36, 454, 29);
		contentPane.add(lblNewLabel_1);
		
		JTextField txtName = new JTextField();
		txtName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtName.setColumns(10);
		txtName.setBounds(966, 82, 264, 38);
		contentPane.add(txtName);
		
		JTextField txtSurname = new JTextField();
		txtSurname.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtSurname.setColumns(10);
		txtSurname.setBounds(966, 134, 264, 38);
		contentPane.add(txtSurname);
		
		JTextField txtUsername = new JTextField();
		txtUsername.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtUsername.setColumns(10);
		txtUsername.setBounds(966, 203, 264, 38);
		contentPane.add(txtUsername);
		
		JTextField txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtEmail.setColumns(10);
		txtEmail.setBounds(966, 266, 264, 38);
		contentPane.add(txtEmail);
		
		JTextField txtPassword = new JTextField();
		txtPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtPassword.setColumns(10);
		txtPassword.setBounds(966, 334, 264, 38);
		contentPane.add(txtPassword);
		
		JTextField txtPhoneNumber = new JTextField();
		txtPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtPhoneNumber.setColumns(10);
		txtPhoneNumber.setBounds(966, 386, 264, 38);
		contentPane.add(txtPhoneNumber);
		
		JButton btnUpdate = new JButton("Insert");
		btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnUpdate.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				
				//check(String              Email, String       Name, String       Password, String 		PhoneNumber, String 	Surname, String 	Username)
				boolean valid = IAWC.check(txtEmail.getText(), txtName.getText(), txtPassword.getText(), txtPhoneNumber.getText(), txtSurname.getText(), txtUsername.getText()); // checking values are valid 
				
				
				if (valid == true)// if the error checking is completed and valid
				{
					String stmt = ""; // create stmt
					//INSERT INTO table_name (column1, column2, column3, ...)
					//VALUES (value1, value2, value3, ...);
					
					stmt = "Insert into RegisterTable (FirstName, Surname, PhoneNumber, Username, Email, Password)";
					stmt += "\n";
					stmt += "VALUES ('" + txtName.getText() + "','" + txtSurname.getText() + "','" + txtPhoneNumber.getText()
					+ "','" + txtUsername.getText() + "','" + txtEmail.getText() + "','" + txtPassword.getText() + "')";
					
					//runs the database update/insert/delete query
				String message2 = db.update(stmt);
				System.out.println(message2);
				JOptionPane.showMessageDialog(null, message2);
				
					JOptionPane.showMessageDialog(null, message2);
					
					//return to admin window after method is complete
					AdminScreen frame = new AdminScreen(num);
					frame.setVisible(true);
					dispose();
				}else
				{
					JOptionPane.showMessageDialog(null, "Something went wrong, please try again");
				}
			}
		});
		btnUpdate.setBounds(788, 438, 430, 110);
		contentPane.add(btnUpdate);
		
		JButton btnBack = new JButton("Back to admin\r\n");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnBack.setBounds(10, 491, 147, 57);
		btnBack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {// the back button to the page before it
				Adminlogin frame = new Adminlogin(num);
				frame.setVisible(true);
				dispose();
			}
			});
		contentPane.add(btnBack);
	}
	}


