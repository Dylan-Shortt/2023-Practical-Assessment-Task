package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Action;

public class AdminScreenProducts extends JFrame {

	private JPanel contentPane;
	private DatabaseConnect db = new DatabaseConnect();
	
	

	/**
	 * Create the frame.
	 */
	public AdminScreenProducts(int num) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 959, 421);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("AdminScreen, used for Administration of the products table"); 
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(10, 0, 925, 37);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 47, 519, 327);
		contentPane.add(scrollPane);
		
		JTextArea textArea = new JTextArea(db.displayMeta("Select ProductID, Quantity, CONCAT('R', CAST(Price AS DECIMAL(10, 2))) AS Cost, ProductName from Products"));// loads products table
		textArea.setTabSize(15);
		scrollPane.setViewportView(textArea);
		
		JButton btnUpdate = new JButton("Update");// button to update the contents of the products table
		btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnUpdate.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				UpdateAdminProducts frame = new UpdateAdminProducts(num);
				frame.setVisible(true);
				dispose();
			}
			});
		btnUpdate.setBounds(539, 47, 406, 59);
		contentPane.add(btnUpdate);
		
		JButton btnInsert = new JButton("Insert");// button to open the insert screen for products table
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				InsertAdminProducts frame = new InsertAdminProducts(num);
				frame.setVisible(true);
				dispose();
			}
			});
		btnInsert.setBounds(539, 135, 406, 59);
		contentPane.add(btnInsert);
		
		JButton btnDelete = new JButton("Delete");// button to delete from the products table
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnDelete.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				DeleteAdminProducts frame = new DeleteAdminProducts(num);
				frame.setVisible(true);
				dispose();
			}
			});
		btnDelete.setBounds(539, 236, 406, 59);
		contentPane.add(btnDelete);
		
		JButton btnBack = new JButton("Back to Admin Window");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnBack.setBounds(539, 305, 396, 69);// button to return to the last shown screen
		btnBack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				Adminlogin frame = new Adminlogin(num);
				frame.setVisible(true);
				dispose();
			}
			});
		contentPane.add(btnBack);
	}
	
}
