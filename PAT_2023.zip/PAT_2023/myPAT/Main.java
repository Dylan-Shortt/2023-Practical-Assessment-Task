package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.TextArea;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Action;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.beans.PropertyChangeListener;
import java.util.Scanner;
import java.beans.PropertyChangeEvent;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.AbstractListModel;
import javax.swing.JCheckBox;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

import java.io.*;
public class Main extends JFrame {

	private JPanel contentPane;
	//private final Action action = new SwingAction();
	private JLabel lblTitle;
	private JLabel lblSortBy;
	private JButton btnSearch;
	private JTextField txtProductNameSearch;
	private JLabel lblProductName;
	private JLabel lblUsername;
	private DatabaseConnect db = new DatabaseConnect();
	private JScrollPane scrollPane;
	private JButton btnBack;
	private JScrollPane scrollPane_1;


	/**
	 * Create the frame.
	 */
	public Main(int num) {// main frame
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 983, 548);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblTitle = new JLabel("TornadoTakeout");
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setBounds(10, 0, 946, 27);
		contentPane.add(lblTitle);
		
		lblSortBy = new JLabel("Sort By:");
		lblSortBy.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSortBy.setBounds(20, 38, 89, 27);
		contentPane.add(lblSortBy);
		
		JComboBox cmbSortBy = new JComboBox();
		cmbSortBy.setModel(new DefaultComboBoxModel(new String[] {"Quantity", "Price", "ProductID", "ProductName"}));
		cmbSortBy.setFont(new Font("Tahoma", Font.PLAIN, 20));
		cmbSortBy.setBounds(119, 38, 186, 27);
		cmbSortBy.addActionListener(new ActionListener() {// when the combo box value changes
            @Override
            public void actionPerformed(ActionEvent e) {
                // This code will be executed when the JComboBox value changes
            	String cmb = cmbSortBy.getSelectedItem().toString();
    			
            	String returnedValue = db.orderBy(cmb);
				
				//creates a new value based on the search results
				String newValue = db.displayMeta(returnedValue);
				
				//redisplays the data into the table
				JTextArea textArea = new JTextArea(db.displayMeta("Select ProductID, Quantity, CONCAT('R', CAST(Price AS DECIMAL(10, 2))) AS Cost, ProductName from Products"));
				scrollPane.setViewportView(textArea);
				textArea.setTabSize(20);
				textArea.setFont(new Font("Monospaced", Font.PLAIN, 20));
				textArea.setText("");
				textArea.append(newValue);
            }
        });
		contentPane.add(cmbSortBy);
		
		btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) { // Searches the contents based on the letters entered
				//System.out.println(db.Search(txtProductNameSearch.getText()));
				
				//runs the database search method
				String search = txtProductNameSearch.getText();
				if(search.isBlank() || search.isEmpty())
				{
					search = "";
				}
				String returnedValue = db.Search(search);
				
				//creates a new value based on the search results
				String newValue = db.displayMeta(returnedValue);
				
				//redisplays the data into the table
				JTextArea textArea = new JTextArea(db.displayMeta("Select ProductID, Quantity, CONCAT('R', CAST(Price AS DECIMAL(10, 2))) AS Cost, ProductName from Products"));
				scrollPane.setViewportView(textArea);
				textArea.setTabSize(20);
				textArea.setFont(new Font("Monospaced", Font.PLAIN, 20));
				textArea.setText("");
				textArea.append(newValue);
			}
			});
		btnSearch.setBounds(837, 38, 129, 27);
		contentPane.add(btnSearch);
		
		txtProductNameSearch = new JTextField();
		txtProductNameSearch.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				
			}
		});
		txtProductNameSearch.setBounds(630, 38, 141, 27);
		contentPane.add(txtProductNameSearch);
		txtProductNameSearch.setColumns(10);
		
		lblProductName = new JLabel("Product Name:");
		lblProductName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblProductName.setBounds(456, 38, 141, 27);
		contentPane.add(lblProductName);
		
		lblUsername = new JLabel("");
		lblUsername.setBounds(833, 0, 123, 24);
		contentPane.add(lblUsername);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 75, 928, 294);
		contentPane.add(scrollPane);
		
		
		JTextArea textArea = new JTextArea(db.displayMeta("Select ProductID, Quantity, CONCAT('R', CAST(Price AS DECIMAL(10, 2))) AS Cost, ProductName from Products"));
		scrollPane.setViewportView(textArea);
		textArea.setTabSize(20);
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 20));
		
		JLabel lblShopping = new JLabel("Select the Products you wish to take to the checkout Window\r\n");
		lblShopping.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblShopping.setBounds(20, 379, 440, 27);
		contentPane.add(lblShopping);
		
		JButton btnShop = new JButton("Check out");
		btnShop.setBounds(820, 438, 139, 63);
		contentPane.add(btnShop);
		
		btnBack = new JButton("Back to login");
		 btnBack.addActionListener(new ActionListener() {
		        @Override
		        public void actionPerformed(ActionEvent e) {
		        	Login frame = new Login();
		        	frame.setVisible(true);
		        	dispose();
		        }
		       });
		btnBack.setBounds(0, 405, 139, 63);
		contentPane.add(btnBack);
		
		//gets the names of all the products in the database
		String [] string = db.getProductNames();
		
		//sets the scroll pane
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(456, 379, 222, 122);
		contentPane.add(scrollPane_1);
		
		// creates a new java list that will contain the unique products from the database
		JList listIDValues = new JList();
		scrollPane_1.setViewportView(listIDValues);
		listIDValues.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		//creates the model of the list to set how the list should look
		listIDValues.setModel(new AbstractListModel() {
			// makes the List = the values from the database
			String[] values = string;
			
			//returns the size of the database
			public int getSize() {
				return values.length;
			}
			
			public Object getElementAt(int index) {//sets the data of the list to different values
				return values[index];
			}
		});
		
		JSpinner spnAddItem = new JSpinner();
		spnAddItem.setModel(new SpinnerNumberModel(0, 0, 5, 1));
		spnAddItem.setFont(new Font("Tahoma", Font.PLAIN, 15));
		spnAddItem.setBounds(737, 421, 83, 47);
		contentPane.add(spnAddItem);
		
		JButton btnAdd = new JButton("Add\r\n");
		btnAdd.setBounds(820, 379, 139, 63);
		contentPane.add(btnAdd);
		
		JLabel lblNewLabel = new JLabel("Amount of Item");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel.setBounds(681, 379, 139, 34);
		contentPane.add(lblNewLabel);
		try {
		    btnAdd.addActionListener(new ActionListener() {
		        @Override
		        public void actionPerformed(ActionEvent e) {
		            // create a fileWriter in append mode
		            try (FileWriter fileWriter = new FileWriter("cart.txt", true);
		                 // create the object to write to the file
		                 PrintWriter printWriter = new PrintWriter(fileWriter)) {

		                // get the file value from the list
		                String passOn = listIDValues.getSelectedValuesList().toString();
		                // trim the [] of the object name
		                passOn = passOn.substring(1, passOn.length() - 1).trim();
		                
		                double cost = db.totalDue("ProductName LIKE \"" + passOn + "\"");
		                	
		                JOptionPane.showMessageDialog(null, "Due: R" + cost + ", the amount is : " + spnAddItem.getValue()
		                 + ", Total cost is : R" + (cost* Integer.parseInt(spnAddItem.getValue().toString())));
		                // write to the file
		                printWriter.print(passOn + "#" + spnAddItem.getValue().toString() + "#" + cost + "\n");
		                
		                // flush and close the PrintWriter (no need to close FileWriter)
		                printWriter.flush();
		                
		                //Remove Items from the Shop after they have been purchased
		               
		                //UPDATE Products
		                //SET Quantity = Quantity - 5
		                //WHERE ProductName LIKE "ITEM"
		                
		                String SQL = "";
		                //create statement
		                
		                SQL = "UPDATE Products SET Quantity = Quantity - " + spnAddItem.getValue()
		                		+ " WHERE ProductName LIKE \"" + passOn + "\"";
		                
		                //run statement
		                db.update(SQL);
		                
		                //set Amount to zero
		                spnAddItem.setValue(0);
		                
		            } catch (IOException ex) {
		                // Handle or log the error
		                ex.printStackTrace();
		                JOptionPane.showMessageDialog(null, "Error writing to cart.txt");
		            }
		        }
		    });
		} catch (Exception e) {
		    e.printStackTrace();
		}

		
		btnShop.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) { // this method is used to take the items
				// to the check out screen, it moves them from one screen to another and 
				// allows them to be displayed separately 
				
				CheckOut frame = new CheckOut(num);
				
				frame.setVisible(true);
				
				dispose();
				
			}
			});
		
	}
}
