package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class UpdateAdminProducts extends JFrame {
	private DatabaseConnect db = new DatabaseConnect();
	private JPanel contentPane;
	private JTextField txtProductID;
	private JTextField txtProductQuantity;
	private JTextField txtProductPrice;
	private JTextField txtWhere;
	private JTextField txtProductName;
	private JTextField txtQuantity;
	private JTextField txtPrice;
	private JTextField txtwhere;

	/**
	 * Create the frame.
	 */
	public UpdateAdminProducts(int num) {
		getContentPane().setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1123, 530);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea textArea = new JTextArea(db.displayMeta("Select ProductID, Quantity, CONCAT('R', CAST(Price AS DECIMAL(10, 2))) AS Cost, ProductName from Products"));
		textArea.setBounds(10, 76, 634, 287);
		contentPane.add(textArea);
		
		JLabel lblTitle = new JLabel("Enter the data that needs to be updated : ");
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTitle.setBounds(53, 10, 586, 50);
		contentPane.add(lblTitle);
		
		JLabel lblNewLabel = new JLabel("Enter the following date in the named area's to update them : ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(487, 33, 586, 27);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Product Name:\r\n");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(654, 156, 207, 27);
		contentPane.add(lblNewLabel_1);
		
		txtProductName = new JTextField();
		txtProductName.setBounds(871, 153, 202, 30);
		contentPane.add(txtProductName);
		txtProductName.setColumns(10);
		
		JLabel lblNewLabel_1_2 = new JLabel("Product Quantity:\r\n");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_2.setBounds(654, 212, 207, 27);
		contentPane.add(lblNewLabel_1_2);
		
		txtQuantity = new JTextField();
		txtQuantity.setColumns(10);
		txtQuantity.setBounds(871, 209, 202, 30);
		contentPane.add(txtQuantity);
		
		JLabel lblNewLabel_1_3 = new JLabel("Product Price:\r\n");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_3.setBounds(654, 276, 207, 27);
		contentPane.add(lblNewLabel_1_3);
		
		txtPrice = new JTextField();
		txtPrice.setColumns(10);
		txtPrice.setBounds(871, 273, 202, 30);
		contentPane.add(txtPrice);
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnBack.setBounds(10, 433, 98, 50);
		btnBack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				AdminScreenProducts frame = new AdminScreenProducts(num);
				frame.setVisible(true);
				dispose();
			}
		});
		contentPane.add(btnBack);
		
		JLabel lblNewLabel_2 = new JLabel("To update select the field you wish to update on:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(20, 378, 330, 45);
		contentPane.add(lblNewLabel_2);
		
		JComboBox cmbCondition = new JComboBox();
		cmbCondition.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cmbCondition.setModel(new DefaultComboBoxModel(new String[] {"ProductName", "ProductID", "Quantity", "Price"}));
		cmbCondition.setBounds(360, 378, 132, 45);
		contentPane.add(cmbCondition);
		
		JLabel lblNewLabel_3 = new JLabel("And enter the condition to match the fields value:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(517, 378, 341, 45);
		contentPane.add(lblNewLabel_3);
		
		txtwhere = new JTextField();
		txtwhere.setBounds(871, 380, 98, 45);
		contentPane.add(txtwhere);
		txtwhere.setColumns(10);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setBounds(979, 421, 120, 62);
		btnUpdate.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				
				UpdateAdminWindowCheck UAWC = new UpdateAdminWindowCheck();
				
				//String to check values
				
					String valid = UAWC.ProductsCheckLetter(cmbCondition.getSelectedItem().toString(),txtwhere.getText() ,txtProductName.getText(), txtQuantity.getText(), txtPrice.getText());
					db.update(valid);
			//	System.out.println("update run");
				
				
				//open update Window
				AdminScreenProducts frame = new AdminScreenProducts(num);
				frame.setVisible(true);
				dispose();
				
			}
			});
		contentPane.add(btnUpdate);
		
		
	}
}
