package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Action;
import java.awt.Color;
import javax.swing.JScrollPane;

public class Register extends JFrame {
	private JPanel contentPane;
	private JLabel lblFirstName;
	private JLabel lblFirstNameError;
	private JLabel lblSurname;
	private JLabel lblSurnameError;
	private JLabel lblPhoneNumber;
	private JLabel lblPhoneNumberError;
	private JLabel lblUserName;
	private JLabel lblUserNameError;
	private JLabel lblEmail;
	private JLabel lblEmailError;
	private JLabel lblPassword;
	private JLabel lblPasswordError;
	private DatabaseConnect db = new DatabaseConnect();
	//private final Action action = new SwingAction();
	private JButton btnRegister;
	private JScrollPane scrollPane_1;
	private JScrollPane scrollPane_2;
	private JScrollPane scrollPane_3;
	private JScrollPane scrollPane_4;
	private JScrollPane scrollPane_5;
	private JScrollPane scrollPane_6;
	private JScrollPane scrollPane_7;
	private JScrollPane scrollPane_8;
	private JScrollPane scrollPane_9;
	private JScrollPane scrollPane_10;
	private JScrollPane scrollPane_11;
	private JScrollPane scrollPane;
	//private final Action action = new SwingAction_1();


	/**
	 * Create the frame.
	 */
	public Register() {/// lets users register a new account
		setTitle("Tornado Takeout Register");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 963, 604);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegisterPageMessage = new JLabel("Register Page: Please enter the following information :");
		lblRegisterPageMessage.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblRegisterPageMessage.setBounds(10, 10, 504, 25);
		contentPane.add(lblRegisterPageMessage);
		
		lblFirstName = new JLabel("First Name : ");
		lblFirstName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblFirstName.setBounds(10, 90, 254, 61);
		contentPane.add(lblFirstName);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(274, 90, 240, 61);
		contentPane.add(scrollPane_1);
		
		JTextField txtFirstName = new JTextField();
		scrollPane_1.setViewportView(txtFirstName);
		txtFirstName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtFirstName.setColumns(10);
		
		scrollPane_7 = new JScrollPane();
		scrollPane_7.setBounds(534, 90, 370, 61);
		contentPane.add(scrollPane_7);
		
		lblFirstNameError = new JLabel("");
		scrollPane_7.setViewportView(lblFirstNameError);
		lblFirstNameError.setForeground(new Color(255, 0, 0));
		lblFirstNameError.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		lblSurname = new JLabel("Surname : ");
		lblSurname.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSurname.setBounds(10, 161, 254, 59);
		contentPane.add(lblSurname);
		
		scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(274, 161, 240, 59);
		contentPane.add(scrollPane_2);
		
		JTextField txtSurname = new JTextField();
		scrollPane_2.setViewportView(txtSurname);
		txtSurname.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtSurname.setColumns(10);
		
		scrollPane_8 = new JScrollPane();
		scrollPane_8.setBounds(534, 161, 370, 59);
		contentPane.add(scrollPane_8);
		
		lblSurnameError = new JLabel("");
		scrollPane_8.setViewportView(lblSurnameError);
		lblSurnameError.setForeground(new Color(255, 0, 0));
		lblSurnameError.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		lblPhoneNumber = new JLabel("Phone Number : ");
		lblPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPhoneNumber.setBounds(10, 230, 254, 54);
		contentPane.add(lblPhoneNumber);
		
		scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(274, 230, 240, 54);
		contentPane.add(scrollPane_3);
		
		JTextField txtPhoneNumber = new JTextField();
		scrollPane_3.setViewportView(txtPhoneNumber);
		txtPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtPhoneNumber.setColumns(10);
		
		scrollPane_9 = new JScrollPane();
		scrollPane_9.setBounds(534, 230, 370, 54);
		contentPane.add(scrollPane_9);
		
		lblPhoneNumberError = new JLabel("");
		scrollPane_9.setViewportView(lblPhoneNumberError);
		lblPhoneNumberError.setForeground(new Color(255, 0, 0));
		lblPhoneNumberError.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		lblUserName = new JLabel("UserName : ");
		lblUserName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblUserName.setBounds(10, 294, 254, 57);
		contentPane.add(lblUserName);
		
		scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(274, 294, 240, 57);
		contentPane.add(scrollPane_4);
		
		JTextField txtUserName = new JTextField();
		scrollPane_4.setViewportView(txtUserName);
		txtUserName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtUserName.setColumns(10);
		
		scrollPane_10 = new JScrollPane();
		scrollPane_10.setBounds(534, 294, 370, 57);
		contentPane.add(scrollPane_10);
		
		lblUserNameError = new JLabel("");
		scrollPane_10.setViewportView(lblUserNameError);
		lblUserNameError.setForeground(new Color(255, 0, 0));
		lblUserNameError.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		lblEmail = new JLabel("Email : ");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEmail.setBounds(10, 361, 254, 45);
		contentPane.add(lblEmail);
		
		scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(274, 361, 240, 45);
		contentPane.add(scrollPane_5);
		
		JTextField txtEmail = new JTextField();
		scrollPane_5.setViewportView(txtEmail);
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtEmail.setColumns(10);
		
		scrollPane_11 = new JScrollPane();
		scrollPane_11.setBounds(534, 361, 370, 45);
		contentPane.add(scrollPane_11);
		
		lblEmailError = new JLabel("");
		scrollPane_11.setViewportView(lblEmailError);
		lblEmailError.setForeground(new Color(255, 0, 0));
		lblEmailError.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		lblPassword = new JLabel("Password : ");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPassword.setBounds(10, 416, 254, 45);
		contentPane.add(lblPassword);
		
		scrollPane_6 = new JScrollPane();
		scrollPane_6.setBounds(274, 416, 240, 45);
		contentPane.add(scrollPane_6);
		
		JTextField txtPassword = new JTextField();
		scrollPane_6.setViewportView(txtPassword);
		txtPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtPassword.setColumns(10);
		
		btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) { // register method
				// TODO Auto-generated method stub
				boolean valid = true;
				//Def values
				
				//sets all the error messages default to blank
				lblFirstNameError.setText("");
				lblSurnameError.setText("");
				lblEmailError.setText("");
				lblPhoneNumberError.setText("");
				lblUserNameError.setText("");
				lblPasswordError.setText("");
				
				//create objects and test program, does the back end coding of the program
				
				ClientOOP client = new ClientOOP(txtFirstName.getText(), txtSurname.getText(), 
						txtPhoneNumber.getText(), txtUserName.getText(), 
						txtEmail.getText(), txtPassword.getText());
				
				String message = client.getError();
				
				// returns the errors codes of each variable
				lblFirstNameError.setText(client.getFirstNameError());
				lblSurnameError.setText(client.getSurnameError());
				lblEmailError.setText(client.getEmailError());
				lblPhoneNumberError.setText(client.getPasswordError());
				lblUserNameError.setText(client.getUserNameError());
				lblPasswordError.setText(client.getPasswordError());
				
				String sql = "";
				if(message.isEmpty())
				{
					//save
					//builds the insert query of the table
					sql = "Insert into RegisterTable (FirstName, Surname, PhoneNumber, Username, Email, Password) "
						+ "values ('" + client.getFirstName() + "','" + client.getSurname() + "','" + client.getPhoneNumber() + "','"
						+ client.getUsername() + "','" + client.getEmail() + "','" + client.getPassword() + "')";
					
					message = "Changes has been made";
				
					// runs the update/insert/delete method
				db.update(sql);
				
				//send email, from me to the user
				//warming to user
				JOptionPane.showMessageDialog(null, "Warning this make take a second, we thank you for your patience");
				EmailControl EmailCenter = new EmailControl();
				EmailCenter.emailCenter(txtEmail.getText());
				
				//open Login window
				Login frame = new Login();
				
				frame.setVisible(true);
				
				dispose();
			}
			}
				});
		btnRegister.setBounds(31, 474, 136, 75);
		contentPane.add(btnRegister);
		
		JButton btnBack = new JButton("Back to login");
		btnBack.setBounds(809, 474, 106, 58);
		btnBack.addActionListener(new ActionListener(){ // button to return the user to the login screen
			public void actionPerformed(ActionEvent e) {
				Login frame = new Login();
				frame.setVisible(true);
				dispose();
			}
			});
		contentPane.add(btnBack);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(536, 416, 368, 43);
		contentPane.add(scrollPane);
		
		lblPasswordError = new JLabel("");
		scrollPane.setViewportView(lblPasswordError);
		lblPasswordError.setForeground(new Color(255, 0, 0));
		lblPasswordError.setFont(new Font("Tahoma", Font.PLAIN, 20));
	}
	}

