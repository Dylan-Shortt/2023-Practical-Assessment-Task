/**
 * 
 */
package myPAT;

/**
 * @author dylan
 *
 */
public class InsertAdminWindowCheck {
	private boolean valid = true;
	//checks the insert statements of the register database table
	public boolean check(String Email, String Name, String Password, String PhoneNumber, String Surname, String Username)
	{
		
		//System.out.println(valid);
		
		//Check valid Email
		if(Email.isBlank() || Email.isEmpty())
		{
			valid = false;
			System.out.println("email :" + valid);
		}
		
		//Check valid name
		if(Name.isBlank() || Name.isEmpty())
				{
					valid = false;
					System.out.println("name :" + valid);
				}
		
		//Check valid name
		for (int i = 0; i < Name.length();i++ )
		{
			//Check valid name
			if(Character.isDigit(Name.charAt(i)))
					{
						valid = false;
						System.out.println("name contains only letters:" + valid);
					}
		}
		
		//Check valid password
		if(Password.isBlank() || Password.isEmpty())
				{
					valid = false;
					System.out.println("password :" + valid);
				}
		
		//Check valid PhoneNumber
		if(PhoneNumber.isBlank() || PhoneNumber.isEmpty())
				{
			valid = false;
			System.out.println("phone numeber :" + valid);
				}
		
		//Check valid Surname
		if(Surname.isBlank() || Surname.isEmpty())
				{
			valid = false;
			System.out.println("surname :" + valid);
				}
		//Check valid name
				for (int i = 0; i < Surname.length();i++ )
				{
					//Check valid name
					if(Character.isDigit(Surname.charAt(i)))
							{
								valid = false;
								System.out.println("surname contains only letters:" + valid);
							}
				}
		
		//Check valid Username
		if(Username.isBlank() || Username.isEmpty())
				{
			valid = false;
			System.out.println("username :" + valid);
				}
		System.out.println(valid);
		return valid;
	}
	
	//txtQuantity.getText(), txtPrice.getText(), txtName.getText()
	
	// checks the values of the products table for inserting 
	public boolean checkProducts(String Quantity, String Price, String Name)
	{
		boolean valid = true;
		
		//Check valid Quantity
				if(Quantity.isBlank() || Quantity.isEmpty())
						{
					valid = false;
					System.out.println("Quantity :" + valid);
						}
				
				//Check valid Quantity
				for (int i = 0; i < Quantity.length() - 1;i++ )
				{
					//Check valid Quantity
					if(Character.isLetter(Quantity.charAt(i)))
							{
								valid = false;
								System.out.println("Quantity cannot contain letters:" + valid);
							}
				}
		//Check valid Price
		if(Price.isBlank() || Price.isEmpty())
				{
			valid = false;
			System.out.println("Price :" + valid);
				}
		
		//Check valid Price
				for (int i = 0; i < Price.length() - 1;i++ )
				{
					//Check valid name
					if(Character.isLetter(Price.charAt(i)))
							{
								valid = false;
								System.out.println("Price cannot contain letters:" + valid);
							}
				}
		
		//Check valid Name
				if(Name.isBlank() || Name.isEmpty())
						{
					valid = false;
					System.out.println("Product name :" + valid);
						}
				
				//Check valid name
				for (int i = 0; i < Name.length() - 1;i++ )
				{
					//Check valid name
					if(!Character.isLetter(Name.charAt(i)))
							{
								valid = false;
								System.out.println("name contains only letters:" + valid);
							}
				}
		return valid;
	}
}
