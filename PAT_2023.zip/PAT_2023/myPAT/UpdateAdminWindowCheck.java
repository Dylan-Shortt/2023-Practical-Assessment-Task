/**
 * 
 */
package myPAT;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 * @author dylan
 *
 */
public class UpdateAdminWindowCheck {

	private String message;
	private DatabaseConnect db = new DatabaseConnect();
	
	public String UpdateCheckLetter(String Email, String Name, String Password, String PhoneNumber, String Surname, String Username, String comb, String Where)
	{
		boolean valid = true;
		/*
		 * 	UPDATE table_name
			SET column1 = value1, column2 = value2, ...
			WHERE condition;
		 */
		
		//create statement
		JOptionPane.showMessageDialog(null, "Running update program...");
		String stmt = "UPDATE RegisterTable";
		stmt += " SET ";
		
		
		//TO change the Email
		if(!Email.isBlank() || !Email.isEmpty())
		{
			stmt += "Email = \"" + Email + "\", ";
		}
		
		//Check valid 
		for (int i = 0; i < Email.length() - 1;i++ )
		{
			//Check valid 
			if(!Email.contains("@") || !Email.contains("."))
					{
						valid = false;
						message = ("Error in Item Email: " + valid);
					}
		}
		
		//TO change the name
		if(!Name.isBlank() || !Name.isEmpty())
				{
					String str = "\"" + Name + "\"";
					stmt += "FirstName = " + str + ", ";
				}
		
		//Check valid 
				for (int i = 0; i < Name.length() - 1;i++ )
				{
					//Check valid 
					if(!Character.isLetter(Name.charAt(i)))
							{
								valid = false;
								message = ("Error in Item Name: " + valid);
							}
				}
		
		//to change the password
		if(!Password.isBlank() || !Password.isEmpty())
				{
					stmt += "Password = \"" + Password + "\", ";
				}
		
		//to change the PhoneNumber
		if(!PhoneNumber.isBlank() || !PhoneNumber.isEmpty())
				{
					stmt += "PhoneNumber = \"" + PhoneNumber + "\", ";
				}
		
		//Check valid 
				for (int i = 0; i < PhoneNumber.length() - 1;i++ )
				{
					//Check valid 
					if(!Character.isDigit(PhoneNumber.charAt(i)))
							{
								valid = false;
								message = ("Error in Item PhoneNumber: " + valid);
							}
				}
		
		//to change the Surname
		if(!Surname.isBlank() || !Surname.isEmpty())
				{
					stmt += "Surname = \"" + Surname + "\", ";
				}
		//Check valid 
		for (int i = 0; i < Surname.length() - 1;i++ )
		{
			//Check valid 
			if(Character.isDigit(Surname.charAt(i)))
					{
						valid = false;
						message = ("Error in Item Surname: " + valid);
					}
		}
		
		//to change the Username
		if(!Username.isBlank() || !Username.isEmpty())
				{
					stmt += "Username = \"" + Username + "\", ";
				}
		
		// remove the extra ', ' from the string
		stmt = stmt.substring(0, stmt.length() - 2);
		
		
		//complete the string
		stmt += " " + "WHERE " + comb + " LIKE \"" + Where + "\"";
		//System.out.println("stmt : " + stmt);
		//run the update 
		if(valid == true)
		{
		String message = db.update(stmt);
		}
		return message;
	}

	
	//this method is used to update the products table with new contents
		public String ProductsCheckLetter(String comb, String Where, String name, String Quantity, String Price) {
			// TODO Auto-generated method stub
			/*
			 * 	UPDATE table_name
				SET column1 = value1, column2 = value2, ...
				WHERE condition;
			 */
			
			//create statement
			JOptionPane.showMessageDialog(null, "Running update program...");
			String stmt = "UPDATE Products";
			stmt += " SET ";
			
			//TO change the name
			if(!name.isBlank() || !name.isEmpty())
					{
						String str = "\"" + name + "\"";
						stmt += "ProductName = " + str + ", ";
						//Check valid 
						for (int i = 0; i < name.length() - 1;i++ )
						{
							//Check valid 
							if(Character.isDigit(name.charAt(i)))
									{
										stmt = null;
										JOptionPane.showMessageDialog(null, "Error in name," + name + " cannot contain this value: " + name.charAt(i));
										
									}
						}
						
					}
			
			
			//to change the password
			if(!Quantity.isBlank() || !Quantity.isEmpty())
					{
						stmt += "Quantity = \"" + Quantity + "\", ";
						//Check valid 
						for (int i = 0; i < Quantity.length() - 1;i++ )
						{
							//Check valid 
							if(Character.isLetter(Quantity.charAt(i)))
									{
										stmt = null;
										JOptionPane.showMessageDialog(null, "Error in Quantity," + Quantity + " cannot contain this value: " + Quantity.charAt(i));
										
									}
						}
						
					}
			
			//to change the PhoneNumber
			if(!Price.isBlank() || !Price.isEmpty())
					{
						stmt += "Price = \"" + Price + "\", ";
						//Check valid 
						for (int i = 0; i < Price.length() - 1;i++ )
						{
							//Check valid 
							if(Character.isLetter(Price.charAt(i)))
									{
										stmt = null;
										JOptionPane.showMessageDialog(null, "Error in Price," + Price + " cannot contain this value:" + Price.charAt(i));
									}
						}
					}
			
			// remove the extra ', ' from the string
			if(stmt != null)
			{
			stmt = stmt.substring(0, stmt.length() - 2);
			}
			
			
			//complete the string
			stmt += " " + "WHERE " + comb + " LIKE " + "\"" + Where + "\"";
			
			//System.out.println(stmt);
			return stmt;
		}
}
