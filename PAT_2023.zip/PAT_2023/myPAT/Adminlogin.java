package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Action;

public class Adminlogin extends JFrame {

	private JPanel contentPane;


	/**
	 * Create the frame.
	 */
	public Adminlogin(int num) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 715, 303);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Admin login screen");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(36, 53, 311, 31);
		contentPane.add(lblNewLabel);
		
		JButton btnMain = new JButton("Proceed to main Menu");
		btnMain.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnMain.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {//button to return to main menu
				Main frame = new Main(num);
				
				frame.setVisible(true);
				
				dispose();
			}
			});
		btnMain.setBounds(10, 117, 286, 58);
		contentPane.add(btnMain);
		
		JButton btnAdmin = new JButton("Admin screen for accounts");
		btnAdmin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAdmin.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {//button to go to admin screen
				AdminScreen frame = new AdminScreen(num);
				frame.setVisible(true);
				dispose();
			}
			});
		btnAdmin.setBounds(357, 117, 311, 58);
		contentPane.add(btnAdmin);
		
		JButton btnAdminShop = new JButton("Admin for shop\r\n");
		btnAdminShop.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAdminShop.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {// button to go to admin screen for products table
				AdminScreenProducts frame = new AdminScreenProducts(num);
				
				frame.setVisible(true);
				
				dispose();
			}
			});
		btnAdminShop.setBounds(357, 185, 311, 52);
		contentPane.add(btnAdminShop);
		
		JButton btnBack = new JButton("Back to login");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnBack.setBounds(10, 185, 286, 52);
		btnBack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {// button to return to login screen
				Login frame = new Login();
				frame.setVisible(true);
				dispose();
			}
			});
		contentPane.add(btnBack);
		
		JButton btnViewTransactions = new JButton("View Transactions History");
		btnViewTransactions.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnViewTransactions.setBounds(357, 39, 311, 68);
		btnViewTransactions.addActionListener(new ActionListener(){// used to view the transactions screen
			public void actionPerformed(ActionEvent e) {
				Admin_tblTransactions frame = new Admin_tblTransactions(num);
				frame.setVisible(true);
				dispose();
			}
			});
		contentPane.add(btnViewTransactions);
	}
}
