package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Action;

public class UpdateAdminWindow extends JFrame {
	private DatabaseConnect db = new DatabaseConnect();
	private JPanel contentPane;
	private UpdateAdminWindowCheck UAWC = new UpdateAdminWindowCheck();
	

	/**
	 * Create the frame.
	 */
	public UpdateAdminWindow(int num) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1324, 595);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 28, 768, 455);
		contentPane.add(scrollPane);
		
		JTextArea txaWindow = new JTextArea(db.displayMeta("Select * from RegisterTable"));
		txaWindow.setTabSize(15);
		scrollPane.setViewportView(txaWindow);
		
		JLabel lblNewLabel = new JLabel("The field to order the update on : \r\n");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(141, 493, 325, 42);
		contentPane.add(lblNewLabel);
		
		JLabel lblFirstName = new JLabel("Name:");
		lblFirstName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblFirstName.setBounds(788, 82, 101, 42);
		contentPane.add(lblFirstName);
		
		JLabel lblSurname = new JLabel("Surname:");
		lblSurname.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSurname.setBounds(788, 134, 101, 42);
		contentPane.add(lblSurname);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblUsername.setBounds(788, 203, 101, 42);
		contentPane.add(lblUsername);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEmail.setBounds(788, 266, 101, 42);
		contentPane.add(lblEmail);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPassword.setBounds(788, 334, 101, 42);
		contentPane.add(lblPassword);
		
		JLabel lblPhoneNumber = new JLabel("PhoneNumber:");
		lblPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPhoneNumber.setBounds(788, 386, 139, 42);
		contentPane.add(lblPhoneNumber);
		
		JLabel lblNewLabel_1 = new JLabel("Enter the values to be replaced along side the following field names : \r\n");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(788, 28, 512, 29);
		contentPane.add(lblNewLabel_1);
		
		JTextField txtName = new JTextField();
		txtName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtName.setColumns(10);
		txtName.setBounds(966, 82, 264, 38);
		contentPane.add(txtName);
		
		JTextField txtSurname = new JTextField();
		txtSurname.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtSurname.setColumns(10);
		txtSurname.setBounds(966, 134, 264, 38);
		contentPane.add(txtSurname);
		
		JTextField txtUsername = new JTextField();
		txtUsername.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtUsername.setColumns(10);
		txtUsername.setBounds(966, 203, 264, 38);
		contentPane.add(txtUsername);
		
		JTextField txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtEmail.setColumns(10);
		txtEmail.setBounds(966, 266, 264, 38);
		contentPane.add(txtEmail);
		
		JTextField txtPassword = new JTextField();
		txtPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtPassword.setColumns(10);
		txtPassword.setBounds(966, 334, 264, 38);
		contentPane.add(txtPassword);
		
		JTextField txtPhoneNumber = new JTextField();
		txtPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtPhoneNumber.setColumns(10);
		txtPhoneNumber.setBounds(966, 386, 264, 38);
		contentPane.add(txtPhoneNumber);
		
		JTextField txtWhere = new JTextField();
		txtWhere.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtWhere.setColumns(10);
		txtWhere.setBounds(906, 496, 133, 38);
		contentPane.add(txtWhere);
		
		JComboBox cmbCondition = new JComboBox();
		cmbCondition.setFont(new Font("Tahoma", Font.PLAIN, 20));
		cmbCondition.setModel(new DefaultComboBoxModel(new String[] {"AccountID", "FirstName", "Surname", "Username", "Email", "Password", "PhoneNumber"}));
		cmbCondition.setBounds(476, 493, 133, 42);
		contentPane.add(cmbCondition);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				//combox, 
				 String comb = (String) cmbCondition.getSelectedItem();
				 System.out.println(comb);
				 //where
				 String where = txtWhere.getText();
				 
				 //(String ID, String Email, String Name, String Password, String PhoneNumber, String Surname, String Username, String comb, String Where)
					
					String message = UAWC.UpdateCheckLetter(txtEmail.getText(), txtName.getText(), txtPassword.getText(), txtPhoneNumber.getText(), txtSurname.getText(), txtUsername.getText(), comb, where);
				

				//return to admin window
				AdminScreen frame = new AdminScreen(num);
				frame.setVisible(true);
				dispose();
				
			}
		});
		btnUpdate.setBounds(1073, 486, 157, 62);
		contentPane.add(btnUpdate);
		
		JLabel lblNewLabel_2 = new JLabel("The value to match the field : \r\n");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(619, 493, 286, 42);
		contentPane.add(lblNewLabel_2);
		
		JButton btnBack = new JButton("back to admin\r\n");
		btnBack.setBounds(20, 487, 108, 63);
		btnBack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				Adminlogin frame = new Adminlogin(num);
				frame.setVisible(true);
				dispose();
			}
			});
		contentPane.add(btnBack);
	}
}
