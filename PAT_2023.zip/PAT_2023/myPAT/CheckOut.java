package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import java.io.*;

import javax.swing.Action;
import javax.swing.JScrollPane;
public class CheckOut extends JFrame {

	private JPanel contentPane;
	//private final Action action = new SwingAction();
	private JLabel lblTitle;
	private JLabel lblSelectedItems;
	private JTextArea txaSelectedItems;
	private JLabel lblTotalCost;
	private JTextArea txaTotalCost;
	private JButton btnProceed;
	private DatabaseConnect db = new DatabaseConnect();
	private JScrollPane scrollPane;
	private Scanner scanner;
	private JButton btnBack;
	private CheckOut_Values ErrorChecking = new CheckOut_Values();
	private Login accountMatcher = new Login();
	

	/**
	 * Create the frame.
	 */
	public CheckOut(int num) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 548, 462);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblTitle = new JLabel("TornadoTakeout Check out");
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setBounds(10, 11, 470, 30);
		contentPane.add(lblTitle);
		
		lblSelectedItems = new JLabel("The selected Items are:");
		lblSelectedItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSelectedItems.setBounds(10, 52, 214, 30);
		contentPane.add(lblSelectedItems);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 93, 214, 299);
		contentPane.add(scrollPane);
		
		String values = ErrorChecking.FetchingValues();
		//fulls text display area
		txaSelectedItems = new JTextArea(db.displayMetaCheckOut("SELECT ProductName, CONCAT('R', CAST(Price AS DECIMAL(10, 2))) AS Cost FROM Products WHERE " + values));
		scrollPane.setViewportView(txaSelectedItems);
		
		lblTotalCost = new JLabel("Total Cost will be:");
		lblTotalCost.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotalCost.setBounds(272, 55, 164, 23);
		contentPane.add(lblTotalCost);
		String TotalDue = ErrorChecking.TotalCost();
		// fills the text display area 
		txaTotalCost = new JTextArea("Total = " + db.displayMeta(TotalDue));
		txaTotalCost.setBounds(272, 93, 164, 43);
		contentPane.add(txaTotalCost);
		
		btnProceed = new JButton("Proceed to purchase.");
		//btnProceed.setAction(action);
		btnProceed.setBounds(272, 168, 164, 56);
		btnProceed.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				//move into tblTransactions through the method given
				String Items = ErrorChecking.Values();
				double amount = ErrorChecking.AmountValues();
				String TotalDue = ErrorChecking.TotalCost();
				
				//add contents to transactions table
				db.Transactions(Items, num, TotalDue, amount);
				Tracking frame; // opens the tracking GUI
				try {
					frame = new Tracking();
					frame.setVisible(true);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				dispose();
				ErrorChecking.ClearTextFile();
			}
		});
		contentPane.add(btnProceed);
		
		btnBack = new JButton("Back to main");
		btnBack.setBounds(272, 266, 164, 56);
		contentPane.add(btnBack);
		btnBack.addActionListener(new ActionListener(){ // opens the main screen with a mouse click
			public void actionPerformed(ActionEvent e) {
				Main frame = new Main(num);
				frame.setVisible(true);
				dispose();
			}
			});
		
	}
	
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "Proceed to purchase.");
			putValue(SHORT_DESCRIPTION, "Buy");
		}
		public void actionPerformed(ActionEvent e) {
		
		
		}
	}
	
}
