package myPAT;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailControl {
    
	public void emailCenter(String email) {

    // Declare recipient's & sender's e-mail id.
    String destmailid = email;
    String sendrmailid = "dylan.shortt_PAT2023@hotmail.com";

    // this is my email account I made for this PAT
    //this will remain the same and never change
    final String MyEmail = "dylan.shortt_PAT2023@hotmail.com";
    final String MyPassword = "cifce6-jepzix-danHov";

    // Use Hotmail's Simple Mail Transfer Protocol server
    String smtphost = "smtp.office365.com"; 
    // Hotmail SMTP server, used to connect to the server to send emails

 // properties
    // "put" works by : when the object is created the compiler will define
    // a space in memory, so put will take my values and put them in the correct
    // space in memory
    Properties props = new Properties();
    props.put("mail.smtp.auth", "true");
    props.put("mail.smtp.starttls.enable", "true");
    props.put("mail.smtp.host", smtphost); // Use Hotmail SMTP server
    props.put("mail.smtp.port", "587"); // Hotmail SMTP port "587"
    props.put("mail.smtp.ssl.trust", smtphost); // Trust Hotmail's SSL certificate
    props.put("mail.smtp.ssl.protocols", "TLSv1.2"); // Use TLSv1.2 protocol, the version to be used

    // Create a Session object & authenticate uid and pwd
    Session sessionobj = Session.getInstance(props, new javax.mail.Authenticator() {
        protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(MyEmail, MyPassword);// check login is okay
        }
    });

    try {
        // Create MimeMessage object & set values
        Message messageobj = new MimeMessage(sessionobj);
        messageobj.setFrom(new InternetAddress(sendrmailid));
        messageobj.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destmailid));
        // subject message: Registration has been successful 
        messageobj.setSubject("Registration has been successful");
        //body message:Thank you for signing up with Tornado Takeout, we look forward to seeing you in our store very soon, until then :)
        messageobj.setText("Thank you for signing up with Tornado Takeout, we look forward to seeing you in our store very soon, until then :)");

        // Test mail was sent correctly
        Transport.send(messageobj);
        //System.out.println("Your email sent successfully....");
    } catch (MessagingException exp) {
        throw new RuntimeException(exp);
    }
}
}


