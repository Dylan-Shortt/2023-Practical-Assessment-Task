package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JScrollPane;

public class InsertAdminProducts extends JFrame {

	private JPanel contentPane;
	private JTextField txtQuantity;
	private JTextField txtPrice;
	private JTextField txtName;
	private DatabaseConnect db = new DatabaseConnect();
	private InsertAdminWindowCheck ErrorChecking = new InsertAdminWindowCheck();

	/**
	 * Create the frame.
	 */
	public InsertAdminProducts(int num) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1076, 544);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Insert Window for Products Table\r\n");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(214, 10, 373, 34);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 61, 585, 332);
		contentPane.add(scrollPane);
		
		// populate text area
		JTextArea textArea = new JTextArea(db.displayMeta("Select ProductID, Quantity, CONCAT('R', CAST(Price AS DECIMAL(10, 2))) AS Cost, ProductName from Products"));
		scrollPane.setViewportView(textArea);
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnBack.setBounds(10, 403, 195, 94);
		btnBack.addActionListener(new ActionListener(){// return to the last opened screen
			public void actionPerformed(ActionEvent e) {
				AdminScreenProducts frame = new AdminScreenProducts(num);
				frame.setVisible(true);
				dispose();
			}
		});
		contentPane.add(btnBack);
		
		JLabel lblNewLabel_1_2 = new JLabel("Quantity : ");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1_2.setBounds(610, 125, 156, 41);
		contentPane.add(lblNewLabel_1_2);
		
		txtQuantity = new JTextField();
		txtQuantity.setColumns(10);
		txtQuantity.setBounds(765, 125, 275, 41);
		contentPane.add(txtQuantity);
		
		JLabel lblNewLabel_1_3 = new JLabel("Price : ");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1_3.setBounds(610, 189, 156, 41);
		contentPane.add(lblNewLabel_1_3);
		
		txtPrice = new JTextField();
		txtPrice.setColumns(10);
		txtPrice.setBounds(765, 189, 275, 41);
		contentPane.add(txtPrice);
		
		JLabel lblNewLabel_1 = new JLabel("Product Name : ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(610, 262, 156, 41);
		contentPane.add(lblNewLabel_1);
		
		txtName = new JTextField();
		txtName.setColumns(10);
		txtName.setBounds(765, 262, 275, 41);
		contentPane.add(txtName);
		
		JButton btnInsert = new JButton("Insert");
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.setBounds(712, 350, 329, 69);
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // runs the SQL for insert
				// TODO Auto-generated method stub
				JOptionPane.showMessageDialog(null, "Running program");
				//run error checking 
				boolean valid = ErrorChecking.checkProducts(txtQuantity.getText(), txtPrice.getText(), txtName.getText()); 
				
				if (valid == true)
				{
					String stmt = ""; // create stmt
					//INSERT INTO table_name (column1, column2, column3, ...)
					//VALUES (value1, value2, value3, ...);
					
					stmt = "Insert into Products (Quantity, Price, ProductName)";
					stmt += "\n";
					stmt += "VALUES ('" + txtQuantity.getText() + "','" + txtPrice.getText() + "','" + txtName.getText() + "')";
					
					//test statement
					//System.out.println(stmt);
					
					//runs the update/Insert/Delete statement
				String message2 = db.update(stmt);
				System.out.println(message2);
				JOptionPane.showMessageDialog(null, message2);
				
					JOptionPane.showMessageDialog(null, message2);
					
					//return to admin window
					AdminScreenProducts frame = new AdminScreenProducts(num);
					frame.setVisible(true);
					dispose();
				}else
				{
					JOptionPane.showMessageDialog(null, "Something went wrong, please try again");
				}
			}
			
		});
		contentPane.add(btnInsert);
	}

}
