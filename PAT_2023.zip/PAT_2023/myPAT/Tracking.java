package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JButton;

public class Tracking extends JFrame {

	private JPanel contentPane;

	

	/**
	 * Create the frame.
	 * @throws InterruptedException 
	 */
	// the last window in the chain of events
	public Tracking() throws InterruptedException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 926, 271);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitle = new JLabel("Tornado Takeout Tracking\r\n");
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTitle.setBounds(10, 11, 256, 35);
		contentPane.add(lblTitle);
		
		JTextArea txaDisplay = new JTextArea();
		txaDisplay.setEditable(false);
		txaDisplay.setFont(new Font("Monospaced", Font.PLAIN, 20));
		txaDisplay.setText("You will be notified when your order is ready, thank you for your buisness");
		txaDisplay.setBounds(10, 56, 892, 90);
		contentPane.add(txaDisplay);
		
		JButton btnWayBack = new JButton("Exit to main window");
		btnWayBack.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnWayBack.setBounds(10, 156, 204, 68);
		btnWayBack.addActionListener(new ActionListener(){
			// allows the user to return to the start of the program and logout 
			public void actionPerformed(ActionEvent e) {
				Login frame = new Login();
				
				frame.setVisible(true);
				
				dispose();
			}
			});
		contentPane.add(btnWayBack);
		
		
		
		
		
	}
}
