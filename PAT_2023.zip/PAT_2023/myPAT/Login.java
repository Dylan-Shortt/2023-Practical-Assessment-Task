package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Action;
import java.awt.Color;
import javax.swing.JPasswordField;
import javax.swing.JToggleButton;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField txtEmail;
	private final Action action = new SwingAction();
	private JLabel lblEmail;
	private JLabel lblEmailError;
	private JLabel lblPassword;
	private JLabel lblPasswordError;
	private JButton btnLogin;
	private JButton btnRegister;
	private JLabel lblLoginError;
	private final Action action_1 = new SwingAction_1();
	private DatabaseConnect DB = new DatabaseConnect();
	private LoginErrorCheck LEC = new LoginErrorCheck();
	private JButton btnGoodBye;
	private JTextField txtPasswordShown;
	private JPasswordField txtPassword;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("Tornado Takeout Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 758, 519);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitle = new JLabel("TornadoTakeout Login");
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblTitle.setBounds(185, 11, 511, 57);
		contentPane.add(lblTitle);
		
		lblEmail = new JLabel("Email :");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEmail.setBounds(72, 79, 156, 41);
		contentPane.add(lblEmail);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtEmail.setBounds(238, 79, 371, 41);
		contentPane.add(txtEmail);
		txtEmail.setColumns(10);
		
		lblEmailError = new JLabel("");
		lblEmailError.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEmailError.setBounds(619, 79, 356, 41);
		contentPane.add(lblEmailError);
		
		lblPassword = new JLabel("Password :");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPassword.setBounds(72, 131, 156, 41);
		contentPane.add(lblPassword);
		
		lblPasswordError = new JLabel("");
		lblPasswordError.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPasswordError.setBounds(619, 131, 356, 41);
		contentPane.add(lblPasswordError);
		
		btnLogin = new JButton("New button");
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnLogin.setAction(action);
		btnLogin.setBounds(72, 224, 156, 64);
		contentPane.add(btnLogin);
		
		btnRegister = new JButton("New button");
		btnRegister.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnRegister.setAction(action_1);
		btnRegister.setBounds(520, 224, 156, 57);
		contentPane.add(btnRegister);
		
		lblLoginError = new JLabel("");
		lblLoginError.setForeground(new Color(255, 0, 0));
		lblLoginError.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblLoginError.setBounds(72, 299, 608, 46);
		contentPane.add(lblLoginError);
		
		btnGoodBye = new JButton("Exit shop\r\n");
		btnGoodBye.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnGoodBye.setBounds(238, 361, 285, 92);
		btnGoodBye.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				//the purpose of this is to let the user chose if they wish to exit the program or not
				int value = JOptionPane.showConfirmDialog(null, "Are you sure you wish you exit the shop ?");
				if(value == 0)
				{
					JOptionPane.showMessageDialog(null, "Come Back again soon !");
					System.exit(0);
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Yeah ! thought we lost you there for a minute!!!");
					
				}
				
			}
			});
		contentPane.add(btnGoodBye);
		
		txtPasswordShown = new JTextField();
		txtPasswordShown.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtPasswordShown.setBounds(238, 130, 371, 42);
		contentPane.add(txtPasswordShown);
		txtPasswordShown.setVisible(false);
		txtPasswordShown.setColumns(10);
		
		txtPassword = new JPasswordField();
		txtPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtPassword.setBounds(236, 130, 373, 42);
		contentPane.add(txtPassword);
		//create show button for password
		JButton btnShow = new JButton("Show\r\n");
		
		//create hide button 
		JButton btnHide = new JButton("Hide");
		btnHide.setBounds(619, 130, 115, 41);
		btnHide.setVisible(false);
		btnHide.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				/// to hide password
				txtPassword.setText(txtPasswordShown.getText());
				txtPasswordShown.setVisible(false);
				txtPassword.setVisible(true);
				btnHide.setVisible(false);
				btnShow.setVisible(true);
				}
			});
		contentPane.add(btnHide);
		
		
		btnShow.setBounds(617, 130, 117, 41);
		btnShow.addActionListener(new ActionListener(){
			//show password
			public void actionPerformed(ActionEvent e) {
				txtPasswordShown.setText(txtPassword.getText());
				txtPassword.setVisible(false);
				txtPasswordShown.setVisible(true);
				btnHide.setVisible(true);
				btnShow.setVisible(false);
				}
			});
		contentPane.add(btnShow);
		
		
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "Login");
			putValue(SHORT_DESCRIPTION, "Login");
		}
		public void actionPerformed(ActionEvent e) {
			//this method is used to check the users login information
			//test factor
			boolean valid;
			//finds the account ID of the user by matching the email address
			int num = DB.findAccID(txtEmail.getText());
			//checks the password and email are from the same account or are real at all
			if(txtPassword.getText().length() < txtPasswordShown.getText().length())
			{
			txtPassword.setText(txtPasswordShown.getText());
			}
			valid = LEC.Check(txtPassword.getText(), txtEmail.getText());
			
			if(valid == true)
			{
				//sql code
				valid = DB.selectLogin(txtEmail.getText(), txtPassword.getText());
				
				//Runs the admin variable to check if the user is an administrator
				boolean admin = DB.isAdminLogin(txtEmail.getText());
				
				if(admin==true)
				{
					//opens window
					Adminlogin frame = new Adminlogin(num);
					frame.setVisible(true);
					dispose();
				}else {
				//code
				if(valid)
				{
				Main frame = new Main(num);
				frame.setVisible(true);
				dispose();
				}
				else
				{
					lblLoginError.setText("Login information is invald!");
				}
			} 
		}else
		{
			lblLoginError.setText("Login information is invald!");
		}
		}
	}
	
	public String getEmail()// returns the entered email as a string to be used to check if valid 
	{
		
		String email = txtEmail.getText();
		//System.out.println("login email " + txtEmail.getText());
		return email;
	}
	
	private class SwingAction_1 extends AbstractAction {
		public SwingAction_1() {
			putValue(NAME, "Register");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {// opens the register window to register an account
			Register frame = new Register();
			
			frame.setVisible(true);
			
			dispose();
			
		}
	}
}
