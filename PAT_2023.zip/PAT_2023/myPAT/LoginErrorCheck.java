/**
 * 
 */
package myPAT;

import java.awt.Color;

/**
 * @author dylan
 *
 */
public class LoginErrorCheck {

	private boolean valid;
	
	public LoginErrorCheck() // sets the valeus to true
	{
		valid = true;
	}
	
	public boolean Check(String password, String email) // the basic error checking done before sending the values to the 
	// database to be matched
	{
		boolean valid = true;
		// if blank error email
		if (password.isBlank() || password.isEmpty())
		{
			valid = false;
		}
		
		// email is blank
		if (email.isBlank() || email.isEmpty())
		{
			valid = false;
		}
		return valid;
			
	}
}