package myPAT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class DeleteAdminProducts extends JFrame {

	private JPanel contentPane;
	private JTextField txtWhere;
	private DatabaseConnect db = new DatabaseConnect();

	/**
	 * Create the frame.
	 */
	public DeleteAdminProducts(int num) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 960, 443);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Delete window for the products table");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(155, 10, 474, 35);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 63, 457, 257);
		contentPane.add(scrollPane);
		
		// fulls text area
		JTextArea textArea = new JTextArea(db.displayMeta("Select ProductID, Quantity, CONCAT('R', CAST(Price AS DECIMAL(10, 2))) AS Cost, ProductName from Products"));
		scrollPane.setViewportView(textArea);
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnBack.setBounds(10, 329, 134, 67);
		btnBack.addActionListener(new ActionListener(){ // button to return to the last screen
			public void actionPerformed(ActionEvent e) {
				AdminScreenProducts frame = new AdminScreenProducts(num);
				frame.setVisible(true);
				dispose();
			}
		});
		contentPane.add(btnBack);
		
		JLabel lblNewLabel_1 = new JLabel("Field to delete from:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(486, 78, 183, 35);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Value to be deleted");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(486, 149, 143, 35);
		contentPane.add(lblNewLabel_2);
		
		txtWhere = new JTextField();
		txtWhere.setBounds(639, 159, 156, 25);
		contentPane.add(txtWhere);
		txtWhere.setColumns(10);
		
		JComboBox cmbCondition = new JComboBox();// combo box to store condition for the SQL delete statement
		cmbCondition.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cmbCondition.setModel(new DefaultComboBoxModel(new String[] {"ProductID", "Quantity", "Price", "ProductName"}));
		cmbCondition.setBounds(640, 87, 155, 26);
		contentPane.add(cmbCondition);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnDelete.setBounds(639, 289, 256, 107);
		btnDelete.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {// button to run delete SQL
				
				if(!txtWhere.getText().isBlank() || !txtWhere.getText().isEmpty())
				{
				String stmt = "";
				
				//DELETE FROM table_name
				stmt = "DELETE FROM Products";
				
				//WHERE condition;
				stmt += " WHERE ";
				
				//Condition
				stmt += cmbCondition.getSelectedItem().toString();
				
				//With match
				
				stmt += " = \"" + txtWhere.getText() + "\"";
				
				//System.out.println(stmt);
				
				//runs the update/insert/delete statement
				String message = db.update(stmt);
				System.out.println(message);
				JOptionPane.showMessageDialog(null, message);
				
				//return to admin window
				AdminScreenProducts frame = new AdminScreenProducts(num);
				frame.setVisible(true);
				dispose();
				}
				else
				{
					JOptionPane.showMessageDialog(null, "must contain a value");
				}
				
			}
		});
		contentPane.add(btnDelete);
	}
}
