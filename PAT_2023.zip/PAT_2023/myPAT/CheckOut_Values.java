/**
 * 
 */
package myPAT;

import java.util.Scanner;
import java.io.*;
/**
 * @author dylan
 *
 */
public class CheckOut_Values {
	
	public void ClearTextFile()
	{
		//delete cart.txt file so it can be rewritten again from a fresh start
		try (FileWriter fileWriter = new FileWriter("cart.txt");
                 // create the object to write to the file
                 PrintWriter printWriter = new PrintWriter(fileWriter)) {
			printWriter.print("");
        } catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	
	public String FetchingValues() {
		// this is used convert the characters
	    // from the main screen of selected products into
		// more use able strings that will be passed
		//into the display area for the checkout screen

	    String Str = "";
	   // System.out.println(string);
	    // Check if the input string has enough characters for the substring operation
	    Scanner scanner;
		try {
			scanner = new Scanner(new File("cart.txt"));
		
	        while (scanner.hasNext()) {
	        	String temp = scanner.nextLine();
	        	Scanner scan = new Scanner(temp).useDelimiter("#");
	        	//finds each product and creates the SQL layout for the string
	            Str += "ProductName LIKE " + "\"" + scan.next() + "\"" + " OR ";
	           
	            // grabs the not need number
	            String filler = scan.next();
	            filler = "";
	       
	        }
	        scanner.close();
	        // removes the extra part of the string in the end
	        try {
	            Str = Str.substring(0, Str.length() - 4);
	        }catch(java.lang.StringIndexOutOfBoundsException e)
	        {
	        	Str = "ProductName LIKE " + "\"" + "null"+ "\"";
	        }
	            
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    return Str;
	}
	
	public String Values() {

	    String Str = "";
	   // System.out.println(string);
	    // Check if the input string has enough characters for the substring operation
	    Scanner scanner;
		try {
			scanner = new Scanner(new File("cart.txt"));
		
	        while (scanner.hasNext()) {
	        	String temp = scanner.nextLine();
	        	Scanner scan = new Scanner(temp).useDelimiter("#");
	        	//finds each product and creates the SQL layout for the string
	            Str += scan.next() + ", ";
	           
	            // grabs the not need number
	            String filler = scan.next();
	            filler = "";
	       
	        }
	        scanner.close();
	        // removes the extra part of the string in the end
	            Str = Str.substring(0, Str.length() - 2);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    return Str;
	}
	
	public int AmountValues() {
		// this is used convert the characters
	    // from the main screen of selected products into
		// more use able strings that will be passed
		//into the display area for the checkout screen

	    String Str = "";
	    int count = 0;
	   // System.out.println(string);
	    // Check if the input string has enough characters for the substring operation
	    Scanner scanner;
		try {
			scanner = new Scanner(new File("cart.txt"));
		
	        while (scanner.hasNext()) {
	        	String temp = scanner.nextLine();
	        	Scanner scan = new Scanner(temp).useDelimiter("#");
	        	//finds each product and creates the SQL layout for the string
	            Str = scan.next();
	           
	            // grabs the not need number
	            count += scan.nextInt();
	       
	        }
	        scanner.close();
	        // removes the extra part of the string in the end
	            Str = Str.substring(0, Str.length() - 2);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    return count;
	}
	
	public String TotalCost() {
		// this is used convert the characters
	    // from the main screen of selected products into
		// more use able strings that will be passed
		//into the display area for the checkout screen

	    String Str = "";
	    int count = 0;
	    double Total = 0;
	   // System.out.println(string);
	    // Check if the input string has enough characters for the substring operation
	    Scanner scanner;
		try {
			scanner = new Scanner(new File("cart.txt"));
		
	        while (scanner.hasNext()) {
	        	String temp = scanner.nextLine();
	        	Scanner scan = new Scanner(temp).useDelimiter("#");
	        	//finds each product and creates the SQL layout for the string
	            Str = scan.next();
	            // grabs the not need number
	            count = scan.nextInt();
	           // System.out.println("count " + count);
	            String temp2 = scan.next();
	            //System.out.println("temp2 " + temp2);
	            double cost = Double.parseDouble(temp2);
	           // System.out.println("cost " + cost);
	            Total += cost*count;
	            //System.out.println("Total " + Total);
	        }
	        scanner.close();
	        // removes the extra part of the string in the end
	        try {
	            Str = Str.substring(0, Str.length() - 2);
	        }catch(java.lang.StringIndexOutOfBoundsException e)
	        {
	        	Str = "0";
	        }
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String output = "R" + Total;
	    return output;
	}
}