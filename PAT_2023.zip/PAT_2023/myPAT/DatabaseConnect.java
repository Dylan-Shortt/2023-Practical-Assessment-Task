package myPAT;
import java.sql.*;
import java.util.*;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

import org.hsqldb.result.ResultMetaData;
public class DatabaseConnect {
	
	
	private Connection conn=null;
	private Statement stmt=null;
	public DatabaseConnect () // constructor for the class
	{
		String database = "TornadoTakeout.accdb";// sets the name of the database
		String driver = "jdbc:ucanaccess://"+database;// the driver path for the class
		try {
			conn=DriverManager.getConnection(driver);// creates connection to the database
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error: " +e);
		}
	}
	
	
	public String displayMetaCheckOut(String sql)// used to populate textAreas
	{
		String output="";// creates output String
		
		try {
			stmt=conn.createStatement();// creates statement
			
			ResultSet rs = stmt.executeQuery(sql);// runs the Query
			ResultSetMetaData meta = rs.getMetaData();
			int size=meta.getColumnCount();
			for(int i = 1; i<= size; i++)// gets the column names from the table
			{
				output+=meta.getColumnName(i) + "\t";
			}
			output+="\n";
			while(rs.next())
			{
				for(int i = 1; i<= size; i++)
				{
					output+=rs.getObject(i)+"\t";// gets the contents in the rows of data
				}
				output+="\n";
			}
			
		} catch (SQLException e) {
			output="Error : " +sql+ "\n";
			//output="Error meta: " +sql+ "\n" + e
		}
		
		return output;// returns the data of the database in a string
	}
	
	public String displayMeta(String sql)// creates a output for textAreas to display the database
	{
		String output="";
		
		try {
			stmt=conn.createStatement();// makes statement
			
			ResultSet rs = stmt.executeQuery(sql);
			ResultSetMetaData meta = rs.getMetaData();// gather data from the query
			int size=meta.getColumnCount();
			for(int i = 1; i<= size; i++)
			{
				output+=meta.getColumnName(i) + "\t";// gets the field names from the database
			}
			output+="\n";
			while(rs.next())
			{
				for(int i = 1; i<= size; i++)
				{
					output+=rs.getObject(i)+"\t";// puts the row information into the statement
				}
				output+="\n";
			}
			
		} catch (SQLException e) {
			output="" +sql+ "\n";
			//output="Error meta: " +sql+ "\n" + e
		}
		
		return output;// returns the statement
	}
	
	public String[] getColumnHeadings(String sql)
	{//to recive the headings from the product table
		try {
			stmt=conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			ResultSetMetaData meta = rs.getMetaData();// runs the query to get column headings
			int size = meta.getColumnCount();
			String[] heading = new String[size];
			
			for(int i = 0; i<size; i++)
			{
				heading[i-1]=meta.getColumnName(i);// adds each heading one by one
			}
			return heading;
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Error: " + e);// error should one occur
		}
		
		return null;
		
	}
	
	public String[][] getRows(String sql)// gets the row information of the data
	{
		try {
			stmt=conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			ResultSetMetaData meta = rs.getMetaData();
			int sizeCol = meta.getColumnCount();
			
			int sizeRow = getSize();// sets the size of the data in the array
			String[][] matrix = new String[sizeRow][sizeCol];
			
			int r=0;
			while(rs.next()) {
				for(int c=0; c<sizeCol; c++)
				{
					matrix[r][c] = "" + rs.getObject(c+1);// adds each object into the arary
				}
				r++;
			}
			return matrix;// retuns the matrix
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Error: " + e);// error message should on occur
		}
		return null;
	}
	
	public int getSize()
	{
		
		try {
			stmt=conn.createStatement();// gets the size of the data to build the row matrix
			ResultSet rs = stmt.executeQuery("Select count(*) from Products");
			if (rs.next()) {
				return rs.getInt(1);// return the data of the size of the rows
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "Error: " + e);
			}
		
		
		return 0;
	}
	
	public String Search(String value) // search through the database
	{
		//SELECT * FROM Products WHERE ProductName LIKE "*c*"
		String sqlstmt = "SELECT ProductID, Quantity, CONCAT('R', CAST(Price AS DECIMAL(10, 2))) AS Cost, ProductName FROM Products WHERE ProductName LIKE \"*" + value + "*\"";
		String output="";
		
		try {
			stmt=conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sqlstmt);
			ResultSetMetaData meta = rs.getMetaData();
			int size=meta.getColumnCount();
			for(int i = 1; i<= size; i++)
			{
				output+=meta.getColumnName(i) + "\t";// adds each heading
			}
			output+="\n";
			while(rs.next())
			{
				for(int i = 1; i<= size; i++)
				{
					output+=rs.getObject(i)+"\t";// add the row data
				}
				output+="\n";
			}
			
		} catch (SQLException e) {
			output="" +sqlstmt+ "\n" + e;
		}
		
		return output;// return the string
	}
	
	public String orderBy(String columnName) {// order by a columnName
	    String sqlstmt = "SELECT ProductID, Quantity, CONCAT('R', CAST(Price AS DECIMAL(10, 2))) AS Cost, ProductName FROM Products ORDER BY " + columnName;
	    
	    // create output statement
	    String output = "";

	    try {
	        PreparedStatement pstmt = conn.prepareStatement(sqlstmt);
	        ResultSet rs = pstmt.executeQuery();// run the query
	        ResultSetMetaData meta = rs.getMetaData();
	        int size = meta.getColumnCount();
	        
	        for (int i = 1; i <= size; i++) {
	            output += meta.getColumnName(i) + "\t";// setup the data to be ordered
	        }
	        output += "\n";

	        while (rs.next()) {
	            for (int i = 1; i <= size; i++) {
	                output += rs.getObject(i) + "\t";// populate the table
	            }
	            output += "\n";
	        }
	    } catch (SQLException e) {
	        output = "" + sqlstmt + "\n" + e;
	    }

	    return output;
	}

	
	public String update(String sqlstmt){//Receive UPDATE/INSERT/DELETE statement
		String message="";
		
			try{
					int iTimeout = 30;
						stmt = conn.createStatement();// create statement
				try{
		
					stmt.setQueryTimeout(iTimeout);
					stmt.executeUpdate( sqlstmt);// runs the statement 
						message="Changes saved";// creates the successful message for the user
		} 
		
		finally {//to close statement when done
					try { 
						
						stmt.close(); 
						
						}
					catch (Exception n) {message = "ERROR: "+n;}// should an error occur return
				}
		} catch (Exception n) {message = "ERROR: "+n;}// should an error occur return
		
			return message;// retunr string
		}
	
	public boolean selectLogin(String email, String password) {// used to check the login of the user
		// sets values
	    Connection connection = conn;
	    PreparedStatement statement = null;
	    ResultSet resultSet = null;

	    try {
	        
	        // Prepare the SQL statement
	        String sql = "SELECT * FROM RegisterTable WHERE Email = ?";
	        statement = connection.prepareStatement(sql);
	        statement.setString(1, email);

	        // Execute the query
	        resultSet = statement.executeQuery();

	        // Check if a matching record is found
	        if (resultSet.next()) {
	            // Retrieve the password from the database
	            String PasswordFromDatabase = resultSet.getString("Password");

	            // Check if the input password matches the hashed password
	            if (PasswordFromDatabase.equals(password)){
	                return true; // Login successful
	            }
	        }
	    } catch (SQLException e) {
	        // Log the error instead of displaying a message
	        e.printStackTrace();
	    } 

	    return false; // Login failed
	}
	
	public boolean isAdminLogin(String email) {// checks if the user is an admin
	    Connection connection = null;
	    PreparedStatement statement = null;
	    ResultSet resultSet = null;

	    try {
	        // Establish database connection
	        connection = conn;

	        // Use parameterized query
	        String sql = "SELECT * FROM RegisterTable WHERE email = ?";
	        PreparedStatement stmt = connection.prepareStatement(sql);
	        stmt.setString(1, email); // Set the parameter value for email
	        resultSet = stmt.executeQuery();

	        if (resultSet.next()) {
	            // Get the value of the "Username" field from the result set
	            String username = resultSet.getString("Username");

	            // Check if the user name in that record matches the set value
	            if ("Administrator".equals(username)) {
	                return true;
	            } else {
	                return false;
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } 
	    return false;
	}
	public void Transactions(String str, int num, String values, double amount)// for the transactions table
	{
		String fix = values.substring(1);
		String SQL = "INSERT INTO tblTransactions (ProductName, AccountID, Price, AmountToBuy)";
		SQL += " VALUES ('" + str + "', '" + num + "', '" + fix + "', '" + amount + "')";
		
		//System.out.println(SQL);
		update(SQL);// used to update tblTransactions when a user purchases an order
	}
	
	public double totalDue(String values) {// calculates the total amount owed 
	    ResultSet resultSet = null;
	    double due = 0;
	    
	    try {
	    	// function to find the sum total
	        String sql = "SELECT ROUND(SUM(Price), 2) FROM Products WHERE " + values;
	        PreparedStatement stmt = conn.prepareStatement(sql);
	        resultSet = stmt.executeQuery();
	        // Find the result row
	        if (resultSet.next()) {
	            due = resultSet.getDouble(1); // Retrieve the sum
	        }
	    } catch (SQLException e) {
	        System.out.println("Error in TotalDue: " + e);
	    }
	    
	    return due;// return amount
	}
	
	// String to recive the values from the products database table and send them to the check out window
	public String[] getProductNames() {
	    List<String> productNamesList = new ArrayList<>();

	    // Create the SQL code to the database
	    String sql = "SELECT ProductName FROM Products";
	    try (PreparedStatement statement = conn.prepareStatement(sql);
	         ResultSet resultSet = statement.executeQuery()) {

	        while (resultSet.next()) {
	            productNamesList.add(resultSet.getString("ProductName"));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace(); // Handle the exception appropriately.
	    }

	    // Convert the ArrayList to an array
	    String[] productNames = productNamesList.toArray(new String[0]);

	    return productNames;
	}
	
	public int findAccID(String email) {
	    int accountNumber = -1; // Initialize with a default value or an appropriate error code

	    // Create the SQL code to the database
	    String sql = "SELECT AccountID FROM RegisterTable WHERE Email LIKE ?";
	    try (PreparedStatement statement = conn.prepareStatement(sql)) {
	        // Set the email parameter
	        statement.setString(1, email);

	        try (ResultSet resultSet = statement.executeQuery()) {
	            if (resultSet.next()) {
	                // If a matching row is found, retrieve the AccountID
	                accountNumber = resultSet.getInt("AccountID");
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace(); // Handle the exception appropriately.
	    }

	    return accountNumber;
	}

}

