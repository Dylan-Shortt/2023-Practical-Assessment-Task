package myPAT;

public class ClientOOP {

	private String FirstName;
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return FirstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	/**
	 * @return the surname
	 */
	public String getSurname() {
		return Surname;
	}

	/**
	 * @param surname the surname to set
	 */
	public void setSurname(String surname) {
		Surname = surname;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return PhoneNumber;
	}

	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return Username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		Username = username;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return Email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		Email = email;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	private String Surname;
	private String PhoneNumber;
	private String Username;
	private String Email;
	private String password;
	private String error;
	private String FirstNameError;
	private String SurnameError;
	private String EmailError;
	private String PhoneNumberError;
	private String UserNameError;
	private String PasswordError;
	
	// the error checking for the register class
	public ClientOOP (String f, String s, String ph, String u, String e, String p)
	{
		//runs the error checking of the register screen
		error = "";
		FirstNameError = "";
		SurnameError = "";
		EmailError = "";
		PhoneNumberError = "";
		UserNameError = "";
		PasswordError = "";
		//error check first Name
		FirstName = f;
		if(!checkValue(f)) FirstNameError =  "Name is blank or empty!\n";
		if(!checkLength(f)) FirstNameError =  "Name is to short! Must have atleast 3 characters\n";
		if(!checkNoNumber(f)) FirstNameError =  "Cannot contain a number!\n";
		if(!checkLongLength(f)) FirstNameError =  "Name is to Long! must be less than 15 characters\n";
		
		//error check Surname
		Surname = s;
		if(!checkValue(s)) SurnameError =  "Surname is blank or empty!\n";
		if(!checkLength(s)) SurnameError =  "Surname is to short! must have at least 3 characters\n";
		if(!checkNoNumber(s)) SurnameError =  "Cannot contain a number!\n";
		if(!checkLongLength(s)) SurnameError =  "Surname is to Long! cannot be more than 15 characters\n";
		
		//error check Phone Number
		PhoneNumber = ph;
		if(!checkValue(ph)) PhoneNumberError =  "Phone number is blank or empty! Must contain 10 characters!\n";
		if(checkNoNumber(ph) == true) PhoneNumberError = "Must only contain numbers";
		//error check Username
		Username = u;
		if(!checkValue(u)) UserNameError =  "Username is blank or empty!\n";
		if(!checkLength(u)) UserNameError =  "Username is to short! must be atleast 3 characters\n";
		if(!checkLongLength(u)) UserNameError =  "Username is to Long! must be atleast 15 characters\n";
		
		//error check Email
		Email = e;
		if(!checkValue(e)) EmailError =  "Email is blank or empty!\n";
		if(!checkValueEmail(e)) EmailError =  "Email does not contain '@' or '.'!\n";
		
		//error check Password
		password = p;
		if(!checkValue(p)) PasswordError =  "Password is blank or empty!\n";
		if(!checkLength(p)) PasswordError =  "Password is to short! must contain atleast 3 characters \n";
		if(!checkLongLength(p)) PasswordError =  "Password is to Long! must contain atleast 15 characters\n";
		
	}
	
	public boolean checkValueEmail(String length)// check email contain required values
	{
		if(!length.contains("@") || !length.contains(".")) return false; else return true;
	}
	
	public boolean checkValue(String length)// check that a value is indeed present
	{
		if(length.isBlank() || length.isEmpty()) return false; else return true;
	}
	
	public boolean checkLength(String length)// checks the lenght is long enough to be valid
	{
		if(length.length() < 3) return false; else return true;
	}
	
	public boolean checkLongLength(String length)//makes sure the length is not to long
	{
		if(length.length() > 15) return false; else return true;
	}

	public boolean checkNoNumber(String length)//makes sure each digit it not a number but a letter
	{
		boolean test = true;
		for ( int i = 0; i < length.length() - 1; i ++)
		{
			if(Character.isDigit(length.charAt(i)) == true)
			{
				test = false;
			}
		}
		return test;
	}
	
	
	public String toString()// creates a toString String of the register client
	{
		String str = "";
		str = "Name: " + FirstName + "\n"
				+ "Surname: " + Surname + "\n"
				+ "PhoneNumber: " + PhoneNumber + "\n"
				+ "Username: " + Username + "\n"
				+"Email: " + Email + "\n"
				+"Password: " + password + "\n";
		return str;
	}

	/**
	 * @return the error
	 */
	public String getError() {
		//used to determine if any errors are present.
		error = FirstNameError + SurnameError + EmailError + PhoneNumberError + UserNameError + PasswordError;
		
		return error;
	}

	/**
	 * @return the firstNameError
	 */
	public String getFirstNameError() {//used to determine if any errors are present.
		return FirstNameError;
	}

	/**
	 * @return the surnameError
	 */
	public String getSurnameError() {//used to determine if any errors are present.
		return SurnameError;
	}

	/**
	 * @return the emailError
	 */
	public String getEmailError() {//used to determine if any errors are present.
		return EmailError;
	}

	/**
	 * @return the phoneNumberError
	 */
	public String getPhoneNumberError() {//used to determine if any errors are present.
		return PhoneNumberError;
	}

	/**
	 * @return the userNameError
	 */
	public String getUserNameError() {//used to determine if any errors are present.
		return UserNameError;
	}

	/**
	 * @return the passwordError
	 */
	public String getPasswordError() {//used to determine if any errors are present.
		return PasswordError;
	}

}
